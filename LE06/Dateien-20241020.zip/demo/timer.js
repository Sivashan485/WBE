setTimeout(() => {
  console.log("fertig :)")
}, 5000)

console.log("starting...")