Quelle für diese Datei:
https://ourworldindata.org/world-population-growth#population-growth-by-country



HINWEIS:

Die Originalversion der CSV-Datei hat in der ersten Zeile einen String, welcher
selbst Kommas enthält. Das macht das Lasen unnötig kompliziert, daher ist die
Originalversion nun unter population_orig.csv abgelegt und eine vereinfachte
Version ist unter population.csv zu finden.
